package com.example.bankapi.controller;

import com.example.bankapi.model.Account;
import com.example.bankapi.service.AuditService;
import com.example.bankapi.service.DownstreamAccountService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.oauth2.jwt.Jwt;
import java.util.HashMap;
import java.util.Map;

import com.example.bankapi.service.TransferService;
@RestController
@RequestMapping("/api/v1/accounts")
public class AccountController {
    // Fields moved inside the class (they were previously declared above the class)
    @SuppressWarnings("unused")
    private final DownstreamAccountService downstreamAccountService;
    @SuppressWarnings("unused")
    private final AuditService auditService;
    private final TransferService transferService;
    public AccountController(AuditService auditService,
                             DownstreamAccountService downstreamAccountService,
                             TransferService transferService) {
        this.auditService = auditService;
        this.downstreamAccountService = downstreamAccountService;
        this.transferService = transferService;
    }

    @GetMapping
    public List<Account> getAll() {
        return transferService.listAccounts();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Account> getById(@PathVariable String id) {
        return transferService.listAccounts().stream()
                .filter(a -> a.id().equals(id))
                .findFirst()
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @GetMapping("/mine")
    public List<Account> getMyAccounts(@AuthenticationPrincipal Jwt jwt) {
        String subject = jwt.getSubject();
        List<String> roles = jwt.getClaimAsStringList("roles");
        if (roles == null) roles = List.of();

        boolean isStaff = roles.contains("teller") || roles.contains("auditor");
        if (isStaff) {
            return transferService.listAccounts();
        }
        return transferService.listAccounts().stream()
                .filter(a -> a.customerId().equals(subject))
                .toList();
    }

    @PostMapping
    public ResponseEntity<Account> create(@RequestBody Account account) {
        // In a real application, you would save the account to a database here.
        // touch auditService to avoid unused-field inspections (real implementation would record the creation)
        if (auditService != null) {
            @SuppressWarnings("unused") String __audit = auditService.toString();
        }
        return ResponseEntity.status(HttpStatus.CREATED).body(account);
    }

    @GetMapping("/me")
    public Map<String, Object> getCurrentUser(@AuthenticationPrincipal Jwt jwt) {
    // TODO 7: Return a Map containing:
    //   "subject"            -- jwt.getSubject()
    //   "issuer"             -- jwt.getIssuer().toString()
    //   "scopes"             -- jwt.getClaimAsString("scope")
    //   "tokenExpiry"        -- jwt.getExpiresAt().toString()
    //   "roles"              -- jwt.getClaimAsStringList("roles"), or an empty list if null
    //   "preferredUsername"  -- jwt.getClaimAsString("preferred_username"), or "not present"
    //   "fullName"           -- jwt.getClaimAsString("name"), or "not present"
    //
    // The service token will NOT have "roles", "preferred_username", or "name"
    // because the token customizer in the Authorization Server only adds those
    // for user-context tokens. This difference is the main thing to observe.
    //return Map.of(); // Replace with your implementation
        Map<String, Object> result = new HashMap<>();
        result.put("subject", jwt.getSubject());
        result.put("issuer", jwt.getIssuer().toString());
        result.put("scopes", jwt.getClaimAsString("scope"));
        result.put("tokenExpiry", jwt.getExpiresAt() != null ? jwt.getExpiresAt().toString() : "not present");
        result.put("roles", jwt.getClaimAsStringList("roles") != null ? jwt.getClaimAsStringList("roles") : List.of());
        result.put("preferredUsername", jwt.getClaimAsString("preferred_username") != null ? jwt.getClaimAsString("preferred_username") : "not present");
        result.put("fullName", jwt.getClaimAsString("name") != null ? jwt.getClaimAsString("name") : "not present");
        return result;
    }

    @GetMapping("/downstream")
    public List<Account> getFromDownstream() {
        return downstreamAccountService.fetchAllFromDownstream();
    }

//     @GetMapping("/{accounts}")
//    public List<Account> getMyAccounts(@AuthenticationPrincipal Jwt jwt) {
//        String subject = jwt.getSubject();
//        List<String> roles = jwt.getClaimAsStringList("roles");
//
//        // If teller or auditor, return all accounts
//        if (roles != null && (roles.contains("teller") || roles.contains("auditor"))) {
//            return ACCOUNTS;
//        }
//
//        // Otherwise, filter to accounts where customerId matches the subject
//        return ACCOUNTS.stream()
//                .filter(a -> a.customerId().equals(subject))
//                .toList();
//    }

}

//@RestController
//@RequestMapping("/api/v1/accounts")
//public class AccountController {

//    private static final List<Account> ACCOUNTS = List.of(
//            new Account("A001", "C001", "CHECKING", new BigDecimal("1250.00")),
//            new Account("A002", "C001", "SAVINGS",  new BigDecimal("8400.00")),
//            new Account("A003", "C002", "CHECKING", new BigDecimal("300.50")),//
//            new Account("A004", "C003", "CHECKING", new BigDecimal("2100.75")),
//            new Account("A005", "C003", "SAVINGS",  new BigDecimal("15000.00"))
 //  );


//    @GetMapping
//    public List<Account> getAll() {
//        return ACCOUNTS;
//    }
//
//    @GetMapping("/{id}")
//    public ResponseEntity<Account> getById(@PathVariable String id) {
//        return ACCOUNTS.stream()
//                .filter(a -> a.id().equals(id))
//                .findFirst()
//                .map(ResponseEntity::ok)
//                .orElse(ResponseEntity.notFound().build());
//    }

    // TODO 1: Add a POST endpoint that accepts an Account in the request body
    // and returns 201 Created with the account in the response body.
    // The endpoint does not need to persist the account -- this is a stub.
    // Annotate the parameter with @RequestBody.
    // Use ResponseEntity.status(HttpStatus.CREATED).body(account) as the return value.
//    @PostMapping
//    public ResponseEntity<Account> create(@RequestBody Account account) {
//        // In a real application, you would save the account to a database here.
//        return ResponseEntity.status(HttpStatus.CREATED).body(account);
//    }



    // TODO 6: Complete this endpoint.
    // @AuthenticationPrincipal instructs Spring Security to inject the validated Jwt
    // from the SecurityContext directly as a method parameter.
    // This is cleaner than calling SecurityContextHolder.getContext() manually.
//    @GetMapping("/me")
//    public Map<String, Object> getCurrentUser(@AuthenticationPrincipal Jwt jwt) {
        // TODO 7: Return a Map containing:
        //   "subject"            -- jwt.getSubject()
        //   "issuer"             -- jwt.getIssuer().toString()
        //   "scopes"             -- jwt.getClaimAsString("scope")
        //   "tokenExpiry"        -- jwt.getExpiresAt().toString()
        //   "roles"              -- jwt.getClaimAsStringList("roles"), or an empty list if null
        //   "preferredUsername"  -- jwt.getClaimAsString("preferred_username"), or "not present"
        //   "fullName"           -- jwt.getClaimAsString("name"), or "not present"
        //
        // The service token will NOT have "roles", "preferred_username", or "name"
        // because the token customizer in the Authorization Server only adds those
        // for user-context tokens. This difference is the main thing to observe.
        //return Map.of(); // Replace with your implementation
//        Map<String, Object> result = new HashMap<>();
//        result.put("subject", jwt.getSubject());
//        result.put("issuer", jwt.getIssuer().toString());
//        result.put("scopes", jwt.getClaimAsString("scope"));
//        result.put("tokenExpiry", jwt.getExpiresAt().toString());
//        result.put("roles", jwt.getClaimAsStringList("roles") != null ? jwt.getClaimAsStringList("roles") : List.of());
//        result.put("preferredUsername", jwt.getClaimAsString("preferred_username") != null ? jwt.getClaimAsString("preferred_username") : "not present");
//        result.put("fullName", jwt.getClaimAsString("name") != null ? jwt.getClaimAsString("name") : "not present");
//        return result;
//    }

    // TODO 10: Add this endpoint to AccountController.
// For a regular account holder it returns only accounts whose customerId
// matches their sub. For a teller or auditor it returns all accounts.
//
// Read jwt.getSubject() and jwt.getClaimAsStringList("roles").
// Filter ACCOUNTS by customerId for account holders.
// Return the full list for tellers and auditors.
//    @GetMapping("/{accounts}")
//    public List<Account> getMyAccounts(@AuthenticationPrincipal Jwt jwt) {
//        String subject = jwt.getSubject();
//        List<String> roles = jwt.getClaimAsStringList("roles");
//
//        // If teller or auditor, return all accounts
//        if (roles != null && (roles.contains("teller") || roles.contains("auditor"))) {
//            return ACCOUNTS;
//        }
//
//        // Otherwise, filter to accounts where customerId matches the subject
//        return ACCOUNTS.stream()
//                .filter(a -> a.customerId().equals(subject))
//                .toList();
//    }


    // TODO 24: Add this endpoint to AccountController.
// It is protected and requires an authenticated caller.
// The inbound request uses the caller's token.
// The outbound call to the downstream service uses the service's own token.
//    private final AuditService auditService;
//    private final DownstreamAccountService downstreamAccountService;
//
//    // Update the constructor to inject both services:
//    public AccountController(AuditService auditService,
//                             DownstreamAccountService downstreamAccountService) {
//        this.auditService = auditService;
//        this.downstreamAccountService = downstreamAccountService;
//    }

//    @GetMapping("/downstream")
//    public List<Account> getFromDownstream() {
//        return downstreamAccountService.fetchAllFromDownstream();
//    }
//}