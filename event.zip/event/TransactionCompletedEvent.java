package com.example.bankservice.event;

import com.example.bankservice.model.Statistic;
import org.springframework.context.ApplicationEvent;

public class TransactionCompletedEvent extends ApplicationEvent {

    private final String transactionType;
    private final Statistic statistic;

    public TransactionCompletedEvent(Object source, String transactionType, Statistic statistic) {
        super(source);
        this.transactionType = transactionType;
        this.statistic = statistic;
    }

    public String getTransactionType() {
        return transactionType;
    }

    public Statistic getStatistic() {
        return statistic;
    }
}
