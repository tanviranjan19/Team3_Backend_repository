package com.example.bankservice.event;

import org.springframework.stereotype.Service;
import org.springframework.transaction.event.TransactionPhase;
import org.springframework.transaction.event.TransactionalEventListener;
import com.example.bankservice.service.TransactionPublisher;

@Service
public class TransactionCompletedEventListener {

    private final TransactionPublisher publisher;

    public TransactionCompletedEventListener(TransactionPublisher publisher) {
        this.publisher = publisher;
    }

    @TransactionalEventListener(phase = TransactionPhase.AFTER_COMMIT)
    public void onTransactionCompleted(TransactionCompletedEvent event) {
        publisher.publish(event.getTransactionType(), event.getStatistic());
    }
}
