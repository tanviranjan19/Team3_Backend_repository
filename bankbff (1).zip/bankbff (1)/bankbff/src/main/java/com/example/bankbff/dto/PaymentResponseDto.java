package com.example.bankbff.dto;

public record PaymentResponseDto(
        String paymentId,
        String status
) {}
