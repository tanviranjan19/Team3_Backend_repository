package com.example.bankbff.dto;

public record WithdrawalResponseDto(
        String withdrawalId,
        String status
) {}
