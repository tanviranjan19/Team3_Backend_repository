package com.example.bankbff.dto;

import java.math.BigDecimal;

public record PaymentRequestDto(
        String fromAccountId,
        String payeeId,
        BigDecimal amount,
        String reference
) {}
