package com.example.bankbff.dto;

public record DepositResponseDto(
        String depositId,
        String status
) {}
