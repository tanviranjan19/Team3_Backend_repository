package com.example.bankbff.controller;

import com.example.bankbff.client.BankingApiClient;
import com.example.bankbff.dto.AccountDto;
import com.example.bankbff.dto.TransferRequestDto;
import com.example.bankbff.dto.TransferResponseDto;
import com.example.bankbff.dto.PaymentRequestDto;
import com.example.bankbff.dto.PaymentResponseDto;
import com.example.bankbff.dto.DepositRequestDto;
import com.example.bankbff.dto.DepositResponseDto;
import com.example.bankbff.dto.WithdrawalRequestDto;
import com.example.bankbff.dto.WithdrawalResponseDto;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * Account-proxy controller.
 *
 * Forwards browser requests to bankapi. The access token is attached
 * automatically by the WebClient filter.
 */
@RestController
@RequestMapping("/api")
public class AccountController {

    private final BankingApiClient bankingApiClient;

    public AccountController(BankingApiClient bankingApiClient) {
        this.bankingApiClient = bankingApiClient;
    }

    @GetMapping("/accounts")
    public List<AccountDto> accounts() {
        // TODO 7.2: Return bankingApiClient.getAccounts().
        return bankingApiClient.getAccounts();

    }

    @PostMapping("/transfers")
    public TransferResponseDto transfer(@RequestBody TransferRequestDto request) {
        // TODO 7.3: Return bankingApiClient.postTransfer(request).
        return bankingApiClient.postTransfer(request);
    }

    @PostMapping("/payments")
    public PaymentResponseDto payment(@RequestBody PaymentRequestDto request) {
        return bankingApiClient.postPayment(request);
    }

    @PostMapping("/deposits")
    public DepositResponseDto deposit(@RequestBody DepositRequestDto request) {
        return bankingApiClient.postDeposit(request);
    }

    @PostMapping("/withdrawals")
    public WithdrawalResponseDto withdrawal(@RequestBody WithdrawalRequestDto request) {
        return bankingApiClient.postWithdrawal(request);
    }
}
